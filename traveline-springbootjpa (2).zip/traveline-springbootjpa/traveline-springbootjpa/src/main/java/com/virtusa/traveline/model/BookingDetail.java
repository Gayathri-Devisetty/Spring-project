package com.virtusa.traveline.model;

import java.sql.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.springframework.data.annotation.CreatedDate;

@Entity
@Table(name="booking_detail")
public class BookingDetail {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int pnr_no;
	
	
	@OneToMany(mappedBy="bookingdetail")
	private Set<PaymentDetail> paymentdetail;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="master_pid", referencedColumnName="passenger_id")
	private PassengerContact passengercontact;
	
	

	@Column(nullable=false)
	private int route_id;
	
	@Column(nullable=false)
	@CreatedDate
	private Date journey_date;
	
	@Column(nullable=false)
	private int total_fare;

	

	public int getRoute_id() {
		return route_id;
	}

	public void setRoute_id(int route_id) {
		this.route_id = route_id;
	}

	public Date getJourney_date() {
		return journey_date;
	}

	public void setJourney_date(Date journey_date) {
		this.journey_date = journey_date;
	}

	public int getTotal_fare() {
		return total_fare;
	}

	public void setTotal_fare(int total_fare) {
		this.total_fare = total_fare;
	}

	public int getPnr_no() {
		return pnr_no;
	}
	
	
	
}
