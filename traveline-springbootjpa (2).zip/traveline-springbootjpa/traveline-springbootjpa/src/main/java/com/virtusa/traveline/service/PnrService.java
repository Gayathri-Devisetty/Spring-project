package com.virtusa.traveline.service;


import com.virtusa.traveline.model.Pnr;

public interface PnrService {
	
	public Pnr getBookingDetailsByPnrNo(String pnrNo);

}
