/*package com.virtusa.traveline.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.traveline.model.PaymentDetail;




public interface PaymentRepository extends JpaRepository<PaymentDetail, Integer>{
 
		 public PaymentDetail findByPnrNo(String pnrNo);
}
*/