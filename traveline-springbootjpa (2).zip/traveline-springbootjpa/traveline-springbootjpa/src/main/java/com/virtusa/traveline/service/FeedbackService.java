package com.virtusa.traveline.service;


import com.virtusa.traveline.model.CustomerFeedback;



	public interface FeedbackService {

		//function to add new feedback
		public String addFeedback(CustomerFeedback customerFeedback);
		
		//function to fetch all feedback
		
	   public CustomerFeedback getCustomerFeedback();
	}

