/*package com.virtusa.traveline.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.virtusa.traveline.model.PaymentDetail;
import com.virtusa.traveline.repository.PaymentRepository;
import com.virtusa.traveline.service.PaymentService;


@Service
@Transactional
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	private  PaymentRepository paymentrepo;

	@Override
	public PaymentDetail getPaymentDetailsByPnrNo(String pnrNo) {
	
		
	        return paymentrepo.findByPnrNo(pnrNo);
	 
	}

}
*/