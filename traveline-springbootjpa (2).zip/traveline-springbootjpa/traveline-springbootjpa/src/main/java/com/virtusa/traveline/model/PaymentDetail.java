package com.virtusa.traveline.model;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="payment_detail")
public class PaymentDetail implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "payment_id", unique = true, nullable = false)
	private int payment_id;
	
	@Column(nullable=false)
	private int total_amount;
	
	@Column(nullable=false)
	private String payment_type;

	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="pmt_pnr_no",referencedColumnName="pnr_no")
	private BookingDetail bookingdetail;
	
	public int getPayment_id() {
		return payment_id;
	}

	public void setPayment_id(int payment_id) {
		this.payment_id = payment_id;
	}


	public int getTotal_amount() {
		return total_amount;
	}

	public void setTotal_amount(int total_amount) {
		this.total_amount = total_amount;
	}

	public String getPayment_type() {
		return payment_type;
	}

	public void setPayment_type(String payment_type) {
		this.payment_type = payment_type;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

	
}
