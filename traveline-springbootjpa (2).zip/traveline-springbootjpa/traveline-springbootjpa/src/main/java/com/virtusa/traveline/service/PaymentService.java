/*package com.virtusa.traveline.service;

import com.virtusa.traveline.model.PaymentDetail;

public interface PaymentService {
	
	  public PaymentDetail getPaymentDetailsByPnrNo(String pnrNo);
	  
	
}
*/