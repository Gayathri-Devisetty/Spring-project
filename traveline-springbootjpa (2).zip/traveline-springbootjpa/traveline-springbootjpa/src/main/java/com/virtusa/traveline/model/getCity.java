package com.virtusa.traveline.model;

import javax.persistence.Column;

public class getCity {

@Column(nullable = false)
private String city;

public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

}
