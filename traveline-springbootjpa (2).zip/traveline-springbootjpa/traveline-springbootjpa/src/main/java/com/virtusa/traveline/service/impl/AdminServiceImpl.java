/*package com.virtusa.traveline.service.impl;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.virtusa.traveline.model.Admin;
import com.virtusa.traveline.repository.AdminRepository;
import com.virtusa.traveline.service.AdminService;

@Service
@Transactional
public class AdminServiceImpl implements AdminService {

	@Autowired
	private  AdminRepository adminrepo;
		
	@PostConstruct
	public void adduser()
	{
		List<Admin> admin1=new ArrayList<Admin>();
		Admin ad=new Admin();
         ad.setAdemail("nitish@gmail.com");
         ad.setAdpassword("12333");
         ad.setAdusername("nitishddd");
         admin1.add(ad);
         adminrepo.saveAll(admin1);
		
	   
	}
	//service method implementation
	@Override
	@Transactional
	public String createAdmin(Admin admin) {
        
		adminrepo.save(admin);
		return "added";
	}
	
	//return all admin
	
	@Override 
	public List<Admin> getAllAdmin() 
	{ // TODO Auto-generated
	  return adminrepo.findAll();
	  }
	 

}
*/