package com.virtusa.traveline.model;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="passenger_contact")
public class PassengerContact implements Serializable {

	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int passenger_id;
	
	@Column(nullable=false)
	private String p_name;
	
	@Column(nullable=false)
	private String p_email;
	
	@Column(nullable=false)
	private String p_contact;
	
	
@OneToMany(mappedBy="passengercontact")
private Set<PassengerDetail> passengerdetail;

@OneToMany(mappedBy="passengercontact")
private Set<BookingDetail> bookingdetail;

public int getPassenger_id() {
	return passenger_id;
}

public void setPassenger_id(int passenger_id) {
	this.passenger_id = passenger_id;
}

public String getP_name() {
	return p_name;
}

public void setP_name(String p_name) {
	this.p_name = p_name;
}

public String getP_email() {
	return p_email;
}

public void setP_email(String p_email) {
	this.p_email = p_email;
}

public String getP_contact() {
	return p_contact;
}

public void setP_contact(String p_contact) {
	this.p_contact = p_contact;
}

public Set<PassengerDetail> getPassengerdetail() {
	return passengerdetail;
}

public void setPassengerdetail(Set<PassengerDetail> passengerdetail) {
	this.passengerdetail = passengerdetail;
}

public Set<BookingDetail> getBookingdetail() {
	return bookingdetail;
}

public void setBookingdetail(Set<BookingDetail> bookingdetail) {
	this.bookingdetail = bookingdetail;
}

public static long getSerialversionuid() {
	return serialVersionUID;
}


}
