package com.virtusa.traveline.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.virtusa.traveline.model.Pnr;
import com.virtusa.traveline.repository.PnrRepository;
import com.virtusa.traveline.service.PnrService;


	@Service
	@Transactional
	public class PnrServiceImpl implements PnrService {

		@Autowired
		private  PnrRepository pnrrepo;

		@Override
		public Pnr getBookingDetailsByPnrNo(String pnrNo) {
			// TODO Auto-generated method stub
			return pnrrepo.find(pnrNo);
			
		}
}
