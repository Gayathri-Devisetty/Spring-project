package com.virtusa.traveline.repository;

import java.sql.ResultSet;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.virtusa.traveline.model.Pnr;
@Repository
public interface PnrRepository extends JpaRepository<Pnr, String> {

	@Query("select booking_detail.journey_date,bus_route.loc_from,bus_route.loc_to,count(passenger_detail.seat_no) as total_seats from booking_detail inner join bus_route on booking_detail.route_id=bus_route.route_id inner join passenger_contact on booking_detail.master_pid=passenger_contact.passenger_id inner join passenger_detail on passenger_contact.passenger_id=passenger_detail.mst_psg_id where booking_detail.pnr_no=pnrno")
	
	
	public ResultSet find(@Param("pnrno") String pnrNo);
}
