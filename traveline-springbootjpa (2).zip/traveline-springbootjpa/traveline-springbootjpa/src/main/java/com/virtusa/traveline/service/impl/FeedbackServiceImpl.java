package com.virtusa.traveline.service.impl;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.virtusa.traveline.model.CustomerFeedback;
import com.virtusa.traveline.repository.FeedbackRepository;
import com.virtusa.traveline.service.FeedbackService;

@Service
@Transactional
public class FeedbackServiceImpl implements FeedbackService {

	@Autowired
	private  FeedbackRepository feedbackrepo;

	@Override
	@Transactional
	public String addFeedback(CustomerFeedback customerFeedback) {
		// TODO Auto-generated method stub
		
		List<CustomerFeedback> feedback1=new ArrayList<CustomerFeedback>();
		CustomerFeedback custFeedback=new CustomerFeedback();
		custFeedback.setPassengeremail("abc@gmail.com");
		custFeedback.setComment("good");
		custFeedback.setPassengername("achyutha");
		feedback1.add(custFeedback);
		feedbackrepo.saveAll(feedback1);
		return null;
		
	}

	@Override
	public CustomerFeedback getCustomerFeedback() {
		// TODO Auto-generated method stub
		return (CustomerFeedback) feedbackrepo.findAll();
	}
	
}
