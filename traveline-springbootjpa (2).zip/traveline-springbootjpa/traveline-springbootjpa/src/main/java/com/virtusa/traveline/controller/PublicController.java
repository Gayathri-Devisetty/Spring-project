package com.virtusa.traveline.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PublicController {

	@RequestMapping(value={"", "/", "index"})
	public String index()
	{
		return "index";
	}
	@RequestMapping("/gallery")
	public String gallery()
	{
		return "gallery";
	}
	@RequestMapping("/contact")
	public String contact()
	{
		return "contact";
	}
	@RequestMapping("/user_module")
	public String userModule()
	{
		return "user_module";
	}
	@RequestMapping("/available_seat")
	public String availableSeat()
	{
		return "bus_seat";
	}
	@RequestMapping("/logout")
	public String logout()
	{
		return "index";
	}
	
	
}
