package com.virtusa.traveline.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.traveline.service.impl.PnrServiceImpl;

@Controller
public class PnrController {

	@Autowired
	private PnrServiceImpl pnrimpl;
	
	@GetMapping("/user_module")
	public ModelAndView get(@RequestAttribute String pnrNo)
	{
		ModelAndView mv=new ModelAndView();
		mv.addObject("add", pnrimpl.getBookingDetailsByPnrNo(pnrNo));
		mv.setViewName("user_module");
		return mv;
		
	}
}
