package com.virtusa.busbooking.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class Pnr {
	
@Column(nullable=false)
private String locFrom;

@Column(nullable=false)
private String locTo;

@Column(nullable=false)
private Date journeyDate;

@Column(nullable=false)
private String pnrNo;

@Column(nullable=false)
private int totalSeats;

public String getLocFrom() {
    return locFrom;
}
public void setLocFrom(String locFrom) {
    this.locFrom = locFrom;
}
public String getLocTo() {
    return locTo;
}
public void setLocTo(String locTo) {
    this.locTo = locTo;
}
public Date getJourneyDate() {
    return journeyDate;
}
public void setJourneyDate(Date journeyDate) {
    this.journeyDate = journeyDate;
}
public String getPnrNo() {
    return pnrNo;
}
public void setPnrNo(String pnrNo) {
    this.pnrNo = pnrNo;
}
public int getTotalSeats() {
    return totalSeats;
}
public void setTotalSeats(int totalSeats) {
    this.totalSeats = totalSeats;
}



}