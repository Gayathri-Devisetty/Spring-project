package com.virtusa.traveline.model;

import java.io.Serializable;

public class CardDetail implements Serializable {

	
	private static final long serialVersionUID = 1L;

	
}
