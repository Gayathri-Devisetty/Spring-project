package com.virtusa.traveline.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

// defining controller to handle the request and response
@Controller
public class AdminPageController {
   
	@RequestMapping("/admin_home")

	public String adminHome(Model model)
	{
		
		return "admin/admin_home";
	}
	@RequestMapping("/viewAdmin")

	public String addadminView()
	{
		
		return "admin/add_admin";
	}
	@GetMapping("/add_bus")
	public String addBus()
	{
		return "admin/add_buses";	
	}

	/*
	 * //receiving value from UI to insert into database
	 * 
	 * @PostMapping("/newAdmin") public String addAdmin(@RequestBody Admin admin) {
	 * adservice.createAdmin(admin); return "added";
	 * 
	 * }
	 */
	@GetMapping("/viewFeedback")
	public String viewFeedback()
	{
		return "admin/viewfeedback";

	}
	@GetMapping("/busList")
	public String buslist()
	{
		return "admin/bus_list";

	}
	
}
