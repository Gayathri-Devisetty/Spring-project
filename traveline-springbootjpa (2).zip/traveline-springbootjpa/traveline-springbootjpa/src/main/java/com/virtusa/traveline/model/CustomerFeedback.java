package com.virtusa.traveline.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="feedback")
public class CustomerFeedback {

@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private int feedback_id;
	
@Column(nullable=false)	
private String passengername;

@Column(nullable=false)
private String passengeremail;

@Column(nullable=false)
private String comment;

public String getPassengername() {
return passengername;
}
public void setPassengername(String passengername) {
this.passengername = passengername;
}
public String getPassengeremail() {
return passengeremail;
}
public void setPassengeremail(String passengeremail) {
this.passengeremail = passengeremail;
}
public String getComment() {
return comment;
}
public void setComment(String comment) {
this.comment = comment;
}
public int getFeedback_id() { 
	return feedback_id;
} 
}