$(document).ready(function(){
    var activeurl =  window.location.pathname.split('/').slice(-1)[0];
$('a[href="'+activeurl+'"]').parent('li').addClass('active');
$('.sidebar a[href="'+activeurl+'"],').addClass('active');

      });
function preventBack(){window.history.forward();}
setTimeout("preventBack()", 0);
window.onunload=function(){null};
