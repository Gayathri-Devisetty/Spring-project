package com.lp.carpool.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.lp.carpool.model.User;
import com.lp.carpool.service.UserService;

@Controller	
public class RegistrationController {
	@Autowired
	private UserService userService;
	
	@GetMapping(value="/registration")
    public String home(Model model)
    {
		System.out.println("--------====================+++++++++++++++++ In REG GET");
        model.addAttribute(new User());
        return "registration";
    }
    
    @PostMapping(value="/registration")
    public String next(@ModelAttribute User user, ModelMap model)
    {
        System.out.println("=======+====="+user.getEmail()+" "+user.getEmpid()+"=============");
        userService.saveUser(user);
        System.out.println("--------====================+++++++++++++++++ In REG SUCCESS");
        //model.addAttribute("nono", "hellooo");
        return "registration";
    }
}


