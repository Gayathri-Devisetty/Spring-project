package com.lp.carpool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CpoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(CpoolApplication.class, args);
	}

}
