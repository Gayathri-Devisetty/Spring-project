package com.virtusa.payroll.controller;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.serviceImpl.EmployeeDetailServiceImpl;

@Controller
public class LoginController {
	@Autowired
	private EmployeeDetailServiceImpl employeeDetailServiceImpl;
	
	 @GetMapping("/EmployeeHome")
	    public ModelAndView EmployeeHome(){
	        ModelAndView modelAndView = new ModelAndView();	       
	        modelAndView.setViewName("EmployeeHome");
	        return modelAndView;
	 } 
	 
	@GetMapping("/login")
	public ModelAndView login(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("login");
        return modelAndView;
        
	}
	
	 @GetMapping("/registration")
	    public ModelAndView registration(){
	        ModelAndView modelAndView = new ModelAndView();
	        Employee employee = new Employee();
	        modelAndView.addObject("employee", employee);
	        modelAndView.setViewName("registration");
	        return modelAndView;
	 }

	 @PostMapping("/registration")
	    public ModelAndView createNewUser(@Valid Employee employee, BindingResult bindingResult) {
	        ModelAndView modelAndView = new ModelAndView();
	        Employee userExists = employeeDetailServiceImpl.findByEmployeeId(employee.getEmployeeId());
	        if (userExists != null) {
	            bindingResult
	                    .rejectValue("UserName", "error.user",
	                            "There is already a user registered with the email provided");
	        }
	        if (bindingResult.hasErrors()) {
	            modelAndView.setViewName("registration");
	        } else {
	            employeeDetailServiceImpl.saveEmployee(employee);
	            modelAndView.addObject("successMessage", "User has been registered successfully");
	            modelAndView.addObject("employee", new Employee());
	            modelAndView.setViewName("registration");

	        }
	        return modelAndView;
	    }

//	    @RequestMapping(value="/home", method = RequestMethod.GET)
//	    public ModelAndView home(){
//	    	System.out.println("heyyy here");
//	        ModelAndView modelAndView = new ModelAndView();
//	        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//	        EmployeeDetail employeeDetail = employeeDetailServiceImpl.findByEmployeeId(auth.getName());
//	       // modelAndView.addObject("userName", "Welcome " + employeeDetail.getName() + " " + user.getLastName() + " (" + user.getEmail() + ")");
//	        modelAndView.addObject("adminMessage","Content Available Only for Users with Admin Role");
//	        modelAndView.setViewName("home");
//	        return modelAndView;
//	    }
	 
	 
	 @GetMapping("/home")
	 public ModelAndView goHome() {
		 ModelAndView modelAndView = new ModelAndView();
		 modelAndView.setViewName("home");
		 return modelAndView;
	 }


	}