package com.virtusa.payroll;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//@ComponentScan("com.virtusa.payroll")
public class PayrollSpringJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PayrollSpringJpaApplication.class, args);
	}

}
