package com.virtusa.payroll.service;

import java.util.List;

import com.virtusa.payroll.model.Employee;


public interface EmployeeDetailService {
	public List<Employee> getData();
	
	public Employee findByEmployeeId(String employeeId);
	
	 public void saveEmployee(Employee employee);
	 
}
