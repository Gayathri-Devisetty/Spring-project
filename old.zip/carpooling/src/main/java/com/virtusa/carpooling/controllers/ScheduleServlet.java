package com.virtusa.carpooling.controllers;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.carpooling.dao.ScheduleDao;
import com.virtusa.carpooling.dao.ScheduleImpl;
import com.virtusa.carpooling.models.Schedule;

/**
 * Servlet implementation class ScheduleServlet
 */
public class ScheduleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ScheduleServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Servlet Started");
		PrintWriter out = response.getWriter();
		Enumeration<String> enumeration = request.getParameterNames();
		String name = null;
		Schedule schedule = new Schedule();
		Hashtable<String, String> ht = new Hashtable<String, String>();
		while (enumeration.hasMoreElements()) {
			name = enumeration.nextElement();
			out.println(name + ":" + request.getParameter(name) + "<br/>");
			ht.put(name, request.getParameter(name));
		}
//        schedule.setScheduleId();
		System.out.println(ht.get("employeeId"));
		schedule.setEmployeeId(Integer.parseInt(ht.get("employeeId")));
		System.out.println(ht.get("startingPoint"));
		schedule.setStartingPoint(ht.get("startingPoint"));
		System.out.println(ht.get("endingPoint"));
		schedule.setEndingPoint(ht.get("endingPoint"));
		System.out.println(ht.get("time"));
		schedule.setTime(ht.get("time"));
		System.out.println(ht.get("vehicleId"));
		schedule.setVehicleId(ht.get("vehicleId"));
		System.out.println(ht.get("numberOfSeats"));
		schedule.setNumberOfSeats(Integer.parseInt(ht.get("numberOfSeats")));

		ScheduleDao si = new ScheduleImpl();
		boolean status = false;
		try {
			status = si.addSchedule(schedule);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (status) {
			out.println("Schedule created successfully");

		} else
			out.println("Sorry, buddy! Schedule not created.");

	}

}
