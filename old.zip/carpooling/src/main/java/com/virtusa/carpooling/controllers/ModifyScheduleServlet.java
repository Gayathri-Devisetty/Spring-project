package com.virtusa.carpooling.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.virtusa.carpooling.dao.ScheduleDao;
import com.virtusa.carpooling.dao.ScheduleImpl;
import com.virtusa.carpooling.models.Schedule;

/**
 * Servlet implementation class ModifyScheduleServlet
 */
public class ModifyScheduleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ModifyScheduleServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)	throws ServletException, IOException {
		System.out.println("Modify Servlet Started");
		PrintWriter out = response.getWriter();
		Enumeration<String> enumeration = request.getParameterNames();
		String name = null;
		Schedule schedule = new Schedule();
		Hashtable<String, String> ht = new Hashtable<String, String>();
		while (enumeration.hasMoreElements()) {
			name = enumeration.nextElement();
			// out.println(name+":"+request.getParameter(name)+"<br/>");
			ht.put(name, request.getParameter(name));
		}
		try {
			schedule.setScheduleId(Integer.parseInt(ht.get("scheduleId")));
		} catch (NumberFormatException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		schedule.setStartingPoint(ht.get("startingPoint"));
		schedule.setEndingPoint(ht.get("endingPoint"));
		schedule.setTime(ht.get("time"));
		schedule.setVehicleId(ht.get("vehicleId"));
		schedule.setNumberOfSeats(Integer.parseInt(ht.get("numberOfSeats")));
		ScheduleDao si = new ScheduleImpl();
		boolean status = false;
		try {
			status = si.updateSchedule(schedule);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (status) {
			out.println("Schedule modified successfully");

		} else
			out.println("Sorry, buddy! Schedule not created.");

	}

}
