package com.virtusa.carpooling.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.carpooling.helpers.MySQLHelper;

public class VehicleImpl implements VehicleDao {
	private Connection conn;
	private CallableStatement callable;
	private PreparedStatement pre;
	private String query;
	private ResourceBundle bundle = ResourceBundle.getBundle("com/virtusa/carpooling/resources/db");
	private ResultSet rs;
	private static Logger logger = Logger.getLogger(UserAccImpl.class);

	static {
		PropertyConfigurator.configure("log4j.properties");
	}

	@Override
	public boolean registerVehicle(String vechileNumber, int numberOfSeats, int employeeId) throws SQLException {
		// TODO Auto-generated method stub

		conn = MySQLHelper.getConnection();
		query=bundle.getString("addVehicle");
		boolean status = false;
		int count=0;
		try {
			pre = conn.prepareStatement(query);
			pre.setString(1,vechileNumber);
			pre.setInt(2, numberOfSeats);
			pre.setInt(3, employeeId);
			pre.setInt(4, numberOfSeats);
			count=pre.executeUpdate();
			if (count>0)
				status = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			conn.close();
		}

		return status;
	}

	@Override
	public boolean vehicleSeatCount(String vechileNumber,int employeeId) throws SQLException {

		// TODO Auto-generated method stub
		conn = MySQLHelper.getConnection();

		boolean status = false;

		int count;
		try {
			callable = conn.prepareCall("{call addmeCount(?,?)}");
			callable.setString(1, vechileNumber);
			callable.setInt(2, employeeId);
			count = callable.executeUpdate();
			if (count > 0)
				status = true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(e);
		} finally {
			conn.close();
		}

		return status;

	}

}
