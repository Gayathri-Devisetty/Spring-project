package com.virtusa.carpooling.models;

public class mainUser {
	
	private long empId;
    private String fullName;
    private String email;
    private String address;
    private String password;
    private int roleId;
    private String oldpassword;
    private long phoneno;
	/**
	 * @return the phoneno
	 */
	public long getPhoneno() {
		return this.phoneno;
	}
	/**
	 * @param phoneno the phoneno to set
	 */
	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
	/**
	 * @return the oldpassword
	 */
	public String getOldpassword() {
		return this.oldpassword;
	}
	/**
	 * @param oldpassword the oldpassword to set
	 */
	public void setOldpassword(String oldpassword) {
		this.oldpassword = oldpassword;
	}
	/**
	 * @return the roleId
	 */
	public int getRoleId() {
		return roleId;
	}
	/**
	 * @param roleId the roleId to set
	 */
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	/**
	 * @return the empId
	 */
	public long getEmpId() {
		return this.empId;
	}
	/**
	 * @param empId the empId to set
	 */
	public void setEmpId(long empId) {
		this.empId = empId;
	}
	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return this.fullName;
	}
	/**
	 * @param fullName the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return this.email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return this.password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
}
