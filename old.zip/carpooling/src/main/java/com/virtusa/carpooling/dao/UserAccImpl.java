package com.virtusa.carpooling.dao;

import java.sql.CallableStatement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.carpooling.dao.UserAccountDao;
import com.virtusa.carpooling.helpers.MySQLHelper;
import com.virtusa.carpooling.models.mainUser;

public class UserAccImpl implements UserAccountDao {
	private Connection conn;
	private CallableStatement callable;
	private PreparedStatement pre;
	private String query;
	private ResourceBundle bundle = ResourceBundle.getBundle("com/virtusa/carpooling/resources/db");
	private ResultSet rs;
	mainUser user;
	private static Logger logger = Logger.getLogger(UserAccImpl.class);
	static {
		PropertyConfigurator.configure("log4j.properties");
	}

	@Override
	public boolean addUser(mainUser user) throws SQLException {
		conn = MySQLHelper.getConnection(); // MySQLHelper to establish connection
		int count = 0;
		query=bundle.getString("addUser");
		boolean status = false;
		try {
			pre = conn.prepareStatement(query);
			pre.setLong(1,user.getEmpId());
			pre.setString(2,user.getFullName());
			pre.setString(3,user.getEmail());
			pre.setString(4,user.getAddress());
			pre.setString(5,user.getPassword());
			pre.setLong(6,user.getPhoneno());
			count=pre.executeUpdate();
			if (count > 0)
				status = true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			conn.close();
		}

		return status;
	}

	@Override
	public mainUser getUserById(int empid) throws SQLException {
		// TODO Auto-generated method stub
		conn = MySQLHelper.getConnection();
		query=bundle.getString("getUser");
		pre = conn.prepareStatement(query);
		pre.setLong(1,empid);
		rs=pre.executeQuery();
		rs.next();
		user = new mainUser();
		user.setEmpId(rs.getInt(1));
		user.setFullName(rs.getString(2));
		user.setEmail(rs.getString(3));
		user.setAddress(rs.getString(4));
		user.setPassword(rs.getString(5));
		user.setRoleId(rs.getInt(6));
		user.setPhoneno(rs.getLong(8));
		conn.close();
		return user;
	}

	@Override
	public boolean updateUser(mainUser user) throws SQLException {
		// TODO Auto-generated method stub

		conn = MySQLHelper.getConnection(); // MySQLHelper to establish connection
		int count = 0;
		boolean status = false;
		try {
			callable = conn.prepareCall("{call updateUser(?,?,?,?,?)}");
			callable.setLong(1, user.getEmpId());
			callable.setString(2, user.getFullName());
			callable.setString(3, user.getEmail());
			callable.setString(4, user.getAddress());
			callable.setLong(5, user.getPhoneno());

			count = callable.executeUpdate();
			if (count > 0)
				status = true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			conn.close();
		}

		return status;

	}

	@Override
	public boolean updateUserPassword(mainUser user) throws SQLException {
		// TODO Auto-generated method stub

		conn = MySQLHelper.getConnection(); // MySQLHelper to establish connection
		int count = 0;
		boolean status = false;
		try {
			callable = conn.prepareCall("{call updateUserPassword(?,?,?)}");
			callable.setLong(1, user.getEmpId());
			callable.setString(2, user.getOldpassword());
			callable.setString(3, user.getPassword());

			count = callable.executeUpdate();
			if (count > 0)
				status = true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(e);
		} finally {
			conn.close();
		}

		return status;
	}

}
