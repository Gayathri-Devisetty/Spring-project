package com.virtusa.carpooling.models;


import java.sql.Time;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.SimpleTimeZone;

public class Schedule {
	
	
//	
//	int tok=3;
//	/**
//	 * @return the tok
//	 */
//	public int getTok() {
//		return tok;
//	}
//	/**
//	 * @param tok the tok to set
//	 */
//	public void setTok(int tok) {
//		this.tok = tok;
//	}
	private int scheduleId;
	private int employeeId;
	private String startingPoint;
	private String endingPoint;
	private Time time;  
	private String vehicleId;
	private int numberOfSeats;
	private int alocsID;
	private long userphone;
	/**
	 * @return the userphone
	 */
	public long getUserphone() {
		return userphone;
	}
	/**
	 * @param userphone the userphone to set
	 */
	public void setUserphone(long userphone) {
		this.userphone = userphone;
	}
	/**
	 * @return the alocsID
	 */
	public int getAlocsID() {
		return alocsID;
	}
	/**
	 * @param alocsID the alocsID to set
	 */
//	public void setAlocsID() {
//		this.alocsID = alocsID;
//	}
//	public int getScheduleId() {
//		return this.scheduleId;
//	}
	public void setScheduleId(int alocsID) {
//	
//		System.out.println("1: "+tok);
//		++tok;
//		System.out.println("2: "+tok);
//		setTok(tok);
		this.scheduleId=alocsID;
	}
	/**
	 * @return the scheduleId
	 */
	public int getScheduleId() {
		return this.scheduleId;
	}
	/**
	 * @param time the time to set
	 */
	public void setTime(Time time) {
		this.time = time;
	}
	public int getEmployeeId() {
		return this.employeeId;
	}
	public void setEmployeeId(int l) {
		this.employeeId = l;
	}
	public String getStartingPoint() {
		return this.startingPoint;
	}
	public void setStartingPoint(String startingPoint) {
		this.startingPoint = startingPoint;
	}
	public String getEndingPoint() {
		return this.endingPoint;
	}
	public void setEndingPoint(String endingPoint) {
		this.endingPoint = endingPoint;
	}
	public String getVehicleId() {
		return this.vehicleId;
	}
	public void setVehicleId(String vehicleId) {
		this.vehicleId = vehicleId;
	}
	public Time getTime() {
		return this.time;
	}
	public void setTime(String time) {
		String[] times=time.split(":");
		try {
			this.time=new Time(Integer.parseInt(times[0]),Integer.parseInt(times[1]),0);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public int getNumberOfSeats() {
		return this.numberOfSeats;
	}
	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}
	
	
}
