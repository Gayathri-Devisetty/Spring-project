package com.virtusa.carpooling.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.virtusa.carpooling.dao.ScheduleDao;
import com.virtusa.carpooling.dao.ScheduleImpl;

/**
 * Servlet implementation class deleteScheduleServlet
 */
public class DeleteScheduleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DeleteScheduleServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("Delete Servlet Started");
		PrintWriter out = response.getWriter();
		ScheduleDao si = new ScheduleImpl();
		boolean status = false;
		int scheduleId = Integer.parseInt(request.getParameter("scheduleId"));
		System.out.println(scheduleId);
		try {
			status = si.deleteSchedule(scheduleId);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (status) {
			out.println("Schedule deleted successfully");
		} else
			out.println("Sorry, buddy! Schedule deletion failed.");

	}

}