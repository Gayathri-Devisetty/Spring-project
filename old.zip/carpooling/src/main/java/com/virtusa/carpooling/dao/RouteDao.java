package com.virtusa.carpooling.dao;

public interface RouteDao {

}
