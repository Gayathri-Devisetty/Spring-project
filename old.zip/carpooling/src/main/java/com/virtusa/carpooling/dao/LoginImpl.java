package com.virtusa.carpooling.dao;

import java.sql.CallableStatement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.carpooling.helpers.MySQLHelper;

public class LoginImpl implements LoginDao {
	private Connection conn;
	private CallableStatement callable;
	private PreparedStatement pre;
	private String query;
	private ResourceBundle bundle = ResourceBundle.getBundle("com/virtusa/carpooling/resources/db");
	private ResultSet rs;
	private static Logger logger = Logger.getLogger(LoginImpl.class);
	static {
		PropertyConfigurator.configure("log4j.properties");
	}

	@Override
	public boolean Validate(int empid, String pass) throws SQLException {
		conn = MySQLHelper.getConnection();
		query=bundle.getString("validateUser");
		boolean status = false;
		int k;
		try {
			pre = conn.prepareStatement(query);
			pre.setInt(1, empid);
			pre.setString(2, pass);
			rs=pre.executeQuery();
			rs.next();
			k=rs.getInt("employeeId");
			System.out.println("Hello ");
			if (k == empid) {
				status = true;
				logger.info("logged in successfully");
			}

		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			status = false;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e);
		}

		finally {
			conn.close();
		}

		return status;
	}

}
