function addMe(addmeRequest) {
	var vId = addmeRequest.parentNode.getAttribute("id");
	alert("Successfully added into the pool");
	window.location.href = "riders.jsp?vehId=" + vId;
	return false;
}
