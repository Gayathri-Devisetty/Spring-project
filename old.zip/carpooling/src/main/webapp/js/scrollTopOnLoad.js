addEventListener("load", function () {
    setTimeout(goToTop, 0);
}, false);

function goToTop() {
    window.scrollTo(0, 1);
}