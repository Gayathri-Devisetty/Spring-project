package com.virtusa.carpooling.testcases;

import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.core.Is.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertThat;
import java.util.Arrays;
import java.util.Collection;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;
import org.junit.runner.RunWith;
import static org.hamcrest.core.Is.*;

import com.virtusa.carpooling.models.mainUser;


@RunWith(value=Parameterized.class)

public class LoginTest {

	private static  mainUser loginmainuser;	
	
	  @Parameter(value = 0)
	  public long empId;
	  @Parameter(value = 1)
	  public String password;
	  
	@Parameters
	public static Collection getTestParameters() {
		return Arrays.asList(new Object[][] {{8062939,"@adT77"}
		,{8062308,"56y"}});
	}
@BeforeClass
public static void createInstance()
{
	loginmainuser=new mainUser();
}

@Before
public void initializeEmployee()
{
	loginmainuser.setEmpId(empId);
	loginmainuser.setPassword(password);
}

@AfterClass
public static void deleteInstance()
{
	loginmainuser=null;
}
@Test
public void testEmpId()
{
	//To check if employeeId is not null
	assertThat(loginmainuser.getEmpId(),is(notNullValue()));
}
@Test
public void testPassword()
{
	//To check if fullName is not null
	assertThat(loginmainuser.getPassword(),is(notNullValue()));
}
@Test
public void testPasswordPattern()
{
	
	//To check if password and fullname are not same
	assertEquals(true, loginmainuser.getPassword().matches("(?=^.{6,15}$)(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&amp;*()_+}{&quot;&quot;:;'?/&gt;.&lt;,]).*$"));
	//assertThat(mainuser.getPassword(), matchesPattern("[a-z]+"));
}
}