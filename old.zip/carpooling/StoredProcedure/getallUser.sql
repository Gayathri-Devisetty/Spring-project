DELIMITER $$

DROP PROCEDURE IF EXISTS getUser $$
create procedure getUser(in p_employeeId int(20))

BEGIN

select * from user where employeeId=p_employeeId;

END $$
DELIMITER ;