DELIMITER $$

 


DROP PROCEDURE IF EXISTS deleteSchedule $$

 


CREATE PROCEDURE deleteSchedule(in p_scheduleId INTEGER(20))


BEGIN

 



delete from schedule where scheduleId=p_scheduleId;


END $$

 



DELIMITER ;