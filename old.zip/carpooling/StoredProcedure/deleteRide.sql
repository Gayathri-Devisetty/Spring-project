DELIMITER $$

 


DROP PROCEDURE IF EXISTS deleteRide $$

 


CREATE PROCEDURE deleteRide(in p_scheduleId INTEGER(20))


BEGIN

 


update vehicle v,schedule s set v.availableSeats=v.availableSeats+1  where s.scheduleId=p_scheduleId and v.vehicleId=s.vehicleId;
delete from riders where tripId=(select tripId from trip where scheduleId=p_scheduleId);
update trip set noOfPassengers=noOfPassengers-1 where scheduleId=p_scheduleId;


END $$

 



DELIMITER ;