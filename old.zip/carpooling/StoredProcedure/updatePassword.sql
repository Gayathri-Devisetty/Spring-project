DELIMITER $$

DROP PROCEDURE IF EXISTS updateUserPassword $$
create procedure updateUserPassword(in p_employeeId int(20),
in p_opassword varchar(30),
in p_npassword varchar(30))

BEGIN

update user set password=p_npassword where employeeId=p_employeeId and password=SHA1(p_opassword);

END $$
DELIMITER ;
