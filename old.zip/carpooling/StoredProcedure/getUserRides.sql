DELIMITER $$

DROP PROCEDURE IF EXISTS getUserRides $$
create procedure getUserRides(in p_employeeId int(20))
BEGIN

select scheduleId,startingPoint, endingPoint,startTime,vehicleId from schedule where scheduleId=(
select scheduleId from trip where tripId=(
select tripId from riders where employeeId=p_employeeId)
);

END $$
DELIMITER ;
